(function (w) {
  w.ENV = {
    API_BASE_URL: 'http://localhost:8080',
    STATIC_BASE_PATH: '/'
  };
})(window);
